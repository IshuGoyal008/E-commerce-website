const express=require('express');
const app=express();
const path=require('path');
const seeddb=require('./seed');
const mongoose = require('mongoose');
//const Product=require('../Modals/Product');
const productroutes=require('./routes/product');
const ejsMate = require('ejs-mate');
const methodOverride = require('method-override');
const reviewroutes=require('./routes/review');

mongoose.connect('mongodb://127.0.0.1:27017/e-commerce')
.then(()=>{
    console.log("DB connected successfully")
})
.catch((err)=>{
    console.log("DB error"); 
    console.log(err)
})
app.engine('ejs' , ejsMate);
app.set('view engine' , 'ejs');
app.set('views' , path.join(__dirname , 'views')); // views folder 
app.use(express.static(path.join(__dirname , 'public'))); // public folder
app.use(express.urlencoded({extended:true}));
app.use(methodOverride('_method'));

app.use(productroutes);
app.use(reviewroutes);

//seeddb();
app.listen(3000,()=>{
    console.log('db connected');
});