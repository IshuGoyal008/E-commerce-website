const express= require('express');
const router=express.Router();
const Product=require('../Modals/Product');
const Reviews=require('../Modals/review');
router.post('/products/:id/review',async(req,res)=>{
    const {id}=req.params;
    const {rating,comments}=req.body;
    const founditem=await Product.findById(id);
    const reviews=new Reviews({rating,comments});
    console.log(reviews);
    founditem.review.push(reviews);
    await reviews.save();
    await founditem.save();
    res.redirect(`/products/${id}`);
});
module.exports=router;