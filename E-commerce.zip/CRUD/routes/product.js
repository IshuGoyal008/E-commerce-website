const express=require('express');
const Product=require('../Modals/Product');
const reviews=require('../Modals/review');
const router=express.Router();

router.get('/products',async(req,res)=>{
    const founditem=await Product.find({});
    res.render('product/index',{founditem});
})
router.get('/products/new',(req,res)=>{
    res.render('product/new');
});
router.post('/products',async(req,res)=>{
    const{name,img,price,description}=req.body;
    await Product.create({name,img,price,description});
    res.redirect('/products');
    console.log("kaam hogya bero");
})
// to show a particular product
router.get('/products/:id',async(req,res)=>{
    let {id}=req.params;
    const founditem=await Product.findById(id).populate('review');// WE DO POPULATE WITH THE HELP OF ID
  //  console.log(founditem);
    res.render('product/show',{founditem});
})
router.get('/products/:id/edit',async(req,res)=>{
    let{id}=req.params;
    const founditem=await Product.findById(id);
    res.render('product/edit',{founditem});

});
router.patch('/products/:id',async(req,res)=>{
    let{id}=req.params;
    let{name,img,price,description}=req.body;
    await Product.findByIdAndUpdate(id,{name,img,price,description});
    res.redirect(`/products/${id}`);
})
router.delete('/products/:id',async(req,res)=>{
    let{id}=req.params;
    let{name,img,price,description,reviews}=req.body;
    const product=await Product.findById(id);
    await Product.findByIdAndDelete(id,product);
    res.redirect('/products');
})






module.exports=router;